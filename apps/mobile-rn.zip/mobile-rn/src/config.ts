// OJO: en el cel NO uses localhost.
// Usa la IP de tu PC (la misma que ves en el QR de Expo).
export const API_URL = "http://10.3.10.49:8000";
