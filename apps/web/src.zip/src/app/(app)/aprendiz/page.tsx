import { redirect } from "next/navigation";

export default function AprendizIndex() {
  redirect("/aprendiz/inicio");
}
